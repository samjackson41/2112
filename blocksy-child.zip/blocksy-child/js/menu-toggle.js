function toggleMenu() { 
    var menu = document.getElementById("megaMenu");
    if (menu) {
        menu.classList.toggle("open");
    }
}